# Roadmap — App Kitesurf (VENTO)

- [x] Design system (tokens areia/laranja, fontes Anton + Space Grotesk)
- [x] Tela Início: hero, pacotes de aula com preços, spots, disponibilidade
- [x] Tela Spots (locais das aulas no Ceará)
- [x] Tela Agenda (disponibilidade + pré-reserva)
- [x] Tela Perfil do aluno (nível, peso, altura, roupa, calçado, idioma)
- [x] Navegação inferior em 4 abas
- [x] Configuração da escola: nome da escola, locais atendidos e preços (editável)
- [x] Metadados de head por rota
- [x] Instalação no celular Android e iOS (ícone e tela inicial)
- [x] Revisão final em celular
