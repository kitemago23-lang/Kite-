<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep school setup, rider profile, and draft bookings behind one typed store so persistent storage can replace the prototype adapter without changing screens.
- Use manifest-only PWA metadata for Android/iOS home-screen installation; offline caching is intentionally excluded to keep previews current.
