import { Link } from "@tanstack/react-router";

const tabs = [
  { to: "/", label: "Início", glyph: "⌂" },
  { to: "/spots", label: "Spots", glyph: "◈" },
  { to: "/agenda", label: "Agenda", glyph: "◷" },
  { to: "/perfil", label: "Perfil", glyph: "◉" },
] as const;

export function BottomTabs() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-foam/95 backdrop-blur">
      <div className="mx-auto grid max-w-md grid-cols-4">
        {tabs.map((tab) => (
          <Link
            key={tab.to}
            to={tab.to}
            activeOptions={{ exact: tab.to === "/" }}
            className="flex flex-col items-center gap-1 py-3 text-ink/40 transition-colors"
            activeProps={{ className: "text-wind" }}
          >
            <span className="grid size-4 shrink-0 place-items-center">{tab.glyph}</span>
            <span className="text-[10px] font-medium">{tab.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
