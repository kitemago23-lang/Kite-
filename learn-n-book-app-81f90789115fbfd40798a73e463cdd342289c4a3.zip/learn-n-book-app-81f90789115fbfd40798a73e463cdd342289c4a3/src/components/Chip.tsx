type ChipProps = {
  label: string;
  selected?: boolean;
  onSelect?: () => void;
};

export function Chip({ label, selected = false, onSelect }: ChipProps) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      className={
        selected
          ? "rounded-full bg-wind px-4 py-2 text-sm font-medium text-foam transition-transform active:scale-95"
          : "rounded-full bg-sand px-4 py-2 text-sm font-medium text-ink transition-transform active:scale-95"
      }
    >
      {label}
    </button>
  );
}

export function ChipGroup({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: readonly string[];
  value: string;
  onChange: (next: string) => void;
}) {
  return (
    <div className="mb-5">
      <p className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <Chip
            key={option}
            label={option}
            selected={value === option}
            onSelect={() => onChange(option)}
          />
        ))}
      </div>
    </div>
  );
}
