import guajiru from "@/assets/spot-guajiru.jpg";
import icarai from "@/assets/spot-icarai.jpg";
import fortaleza from "@/assets/spot-fortaleza.jpg";

export const spotImages: Record<string, string> = {
  guajiru,
  icarai,
  fortaleza,
};

export const spotImageFor = (id: string) => spotImages[id] ?? guajiru;
