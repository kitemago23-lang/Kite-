import { useCallback, useEffect, useState } from "react";

export type Spot = {
  id: string;
  name: string;
  wind: string;
  sea: string;
};

export type Lesson = {
  id: string;
  name: string;
  detail: string;
  price: number;
  level: string;
  languages: string[];
  featured?: boolean;
};

export type School = {
  name: string;
  city: string;
  spots: Spot[];
  lessons: Lesson[];
};

export type RiderProfile = {
  name: string;
  level: string;
  weight: string;
  height: string;
  clothing: string;
  shoe: string;
  language: string;
  notes: string;
};

export type Booking = {
  id: string;
  lessonId: string;
  spotId: string;
  day: string;
  time: string;
  createdAt: string;
};

export const defaultSchool: School = {
  name: "VENTO Kite School",
  city: "Fortaleza · CE",
  spots: [
    { id: "guajiru", name: "Ilha do Guajiru", wind: "18 kn", sea: "Mar calmo" },
    { id: "icarai", name: "Icaraí de Amontada", wind: "14 kn", sea: "Ondas pequenas" },
    { id: "fortaleza", name: "Fortaleza", wind: "22 kn", sea: "Ondas médias" },
  ],
  lessons: [
    {
      id: "primeira-vez",
      name: "Primeira Vez",
      detail: "1 dia · 4h · equipamento incluído",
      price: 280,
      level: "Iniciante",
      languages: ["PT", "EN"],
      featured: true,
    },
    {
      id: "progressao",
      name: "Progressão",
      detail: "3 dias · 12h · certificação",
      price: 720,
      level: "Intermediário",
      languages: ["PT", "EN", "ES"],
    },
    {
      id: "intensivo",
      name: "Intensivo",
      detail: "5 dias · 20h · tudo incluído",
      price: 1450,
      level: "Avançado",
      languages: ["PT", "EN", "ES", "FR"],
    },
  ],
};

export const defaultProfile: RiderProfile = {
  name: "",
  level: "Iniciante",
  weight: "60–80 kg",
  height: "165–180 cm",
  clothing: "G",
  shoe: "42",
  language: "PT",
  notes: "",
};

export const availability = [
  { day: "Seg", date: "12", times: ["08:00", "14:00"] },
  { day: "Ter", date: "13", times: ["08:00", "10:00", "16:00"] },
  { day: "Qua", date: "14", times: ["09:00", "15:00"] },
  { day: "Qui", date: "15", times: ["08:00", "13:00"] },
  { day: "Sex", date: "16", times: ["07:00", "11:00", "16:00"] },
];

export const LANGUAGES = ["PT", "EN", "ES", "FR"];
export const LEVELS = ["Iniciante", "Intermediário", "Avançado"];
export const WEIGHTS = ["< 60 kg", "60–80 kg", "80–100 kg", "100+ kg"];
export const HEIGHTS = ["150–165 cm", "165–180 cm", "180+ cm"];
export const CLOTHING = ["P", "M", "G", "GG"];
export const SHOES = ["36", "38", "40", "42", "44", "46"];

export const formatPrice = (value: number) =>
  `R$ ${value.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}`;

function usePersisted<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(fallback);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) setValue({ ...fallback, ...(JSON.parse(raw) as T) });
    } catch {
      /* ignore corrupted storage */
    }
    setReady(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const update = useCallback(
    (next: T) => {
      setValue(next);
      try {
        localStorage.setItem(key, JSON.stringify(next));
      } catch {
        /* storage unavailable */
      }
    },
    [key],
  );

  return { value, update, ready } as const;
}

export const useSchool = () => usePersisted<School>("vento.school", defaultSchool);
export const useProfile = () => usePersisted<RiderProfile>("vento.profile", defaultProfile);

export function useBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("vento.bookings");
      if (raw) setBookings(JSON.parse(raw) as Booking[]);
    } catch {
      /* ignore */
    }
  }, []);

  const persist = (next: Booking[]) => {
    setBookings(next);
    try {
      localStorage.setItem("vento.bookings", JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const add = (booking: Omit<Booking, "id" | "createdAt">) =>
    persist([
      ...bookings,
      { ...booking, id: crypto.randomUUID(), createdAt: new Date().toISOString() },
    ]);

  const remove = (id: string) => persist(bookings.filter((b) => b.id !== id));

  return { bookings, add, remove } as const;
}
