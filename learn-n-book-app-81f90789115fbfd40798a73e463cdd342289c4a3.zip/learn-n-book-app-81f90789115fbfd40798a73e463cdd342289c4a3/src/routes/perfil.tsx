import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ChipGroup } from "@/components/Chip";
import { CLOTHING, HEIGHTS, LANGUAGES, LEVELS, SHOES, WEIGHTS, useProfile } from "@/lib/school-store";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil do aluno · VENTO" },
      { name: "description", content: "Informe nível, medidas, tamanhos e idioma para preparar sua aula de kitesurf." },
      { property: "og:title", content: "Perfil do aluno · VENTO" },
      { property: "og:description", content: "Dados do aluno para uma aula de kitesurf preparada sob medida." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Perfil,
});

function Perfil() {
  const { value: profile, update } = useProfile();
  const [saved, setSaved] = useState(false);

  const change = (field: keyof typeof profile, value: string) => {
    setSaved(false);
    update({ ...profile, [field]: value });
  };

  return (
    <div className="px-5 pt-8">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-wind">Seu equipamento ideal</p>
      <h1 className="mt-2 font-display text-4xl leading-none">Perfil do aluno</h1>
      <p className="mt-2 text-sm text-ink/60">Essas informações ajudam a escola a separar o equipamento certo antes da aula.</p>

      <div className="mt-6 rounded-[28px] bg-foam p-5 ring-1 ring-border">
        <label htmlFor="name" className="mb-2 block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">Nome</label>
        <input id="name" maxLength={100} value={profile.name} onChange={(event) => change("name", event.target.value)} placeholder="Como devemos chamar você?" className="mb-5 w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none placeholder:text-ink/35 focus:ring-2 focus:ring-wind" />
        <ChipGroup label="Nível" options={LEVELS} value={profile.level} onChange={(value) => change("level", value)} />
        <ChipGroup label="Peso" options={WEIGHTS} value={profile.weight} onChange={(value) => change("weight", value)} />
        <ChipGroup label="Altura" options={HEIGHTS} value={profile.height} onChange={(value) => change("height", value)} />
        <ChipGroup label="Tamanho de roupa" options={CLOTHING} value={profile.clothing} onChange={(value) => change("clothing", value)} />
        <ChipGroup label="Tamanho de calçado" options={SHOES} value={profile.shoe} onChange={(value) => change("shoe", value)} />
        <ChipGroup label="Idioma" options={LANGUAGES} value={profile.language} onChange={(value) => change("language", value)} />
        <label htmlFor="notes" className="mb-2 block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">Observações</label>
        <textarea id="notes" maxLength={500} rows={3} value={profile.notes} onChange={(event) => change("notes", event.target.value)} placeholder="Restrições, objetivo da aula ou outra informação útil" className="w-full resize-none rounded-xl bg-sand px-4 py-3 text-sm outline-none placeholder:text-ink/35 focus:ring-2 focus:ring-wind" />
        <button type="button" onClick={() => setSaved(true)} className="mt-6 w-full rounded-full bg-ink py-3.5 text-sm font-semibold text-foam">{saved ? "Perfil salvo" : "Salvar perfil"}</button>
      </div>

      <Link to="/configuracao" className="my-6 flex items-center justify-between rounded-[24px] bg-deep p-5 text-foam">
        <span><strong className="block font-display text-xl font-normal">Área da escola</strong><small className="mt-1 block text-foam/65">Configurar nome, locais e preços</small></span>
        <span aria-hidden="true">→</span>
      </Link>
    </div>
  );
}