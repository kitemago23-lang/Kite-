import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import heroKite from "@/assets/hero-kite.jpg";
import { spotImageFor } from "@/components/spot-images";
import { ChipGroup } from "@/components/Chip";
import {
  CLOTHING,
  HEIGHTS,
  LANGUAGES,
  LEVELS,
  SHOES,
  WEIGHTS,
  availability,
  formatPrice,
  useBookings,
  useProfile,
  useSchool,
} from "@/lib/school-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VENTO · Aulas de kitesurf no Ceará" },
      {
        name: "description",
        content:
          "Pacotes de aula, preços, spots no Ceará e pré-reserva de aula de kitesurf em poucos toques.",
      },
      { property: "og:title", content: "VENTO · Aulas de kitesurf no Ceará" },
      {
        property: "og:description",
        content: "Pacotes, preços, disponibilidade e pré-reserva de aulas de kitesurf.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const { value: school } = useSchool();
  const { value: profile, update: updateProfile } = useProfile();
  const { add } = useBookings();

  const [lessonId, setLessonId] = useState(school.lessons[0]?.id ?? "");
  const [dayIndex, setDayIndex] = useState(1);
  const [time, setTime] = useState(availability[1]?.times[0] ?? "08:00");

  const spot = school.spots[0];
  const day = availability[dayIndex] ?? availability[0] ?? { day: "Seg", date: "12", times: ["08:00"] };
  const cheapest = Math.min(...school.lessons.map((l) => l.price));

  const submit = () => {
    add({
      lessonId: lessonId || school.lessons[0]?.id || "",
      spotId: spot?.id ?? "",
      day: `${day.day} ${day.date}`,
      time,
    });
    navigate({ to: "/agenda" });
  };

  return (
    <div className="font-body text-ink">
      {/* HERO */}
      <section className="relative">
        <img
          src={heroKite}
          alt="Kitesurfista no fim do dia em uma praia do Ceará"
          width={1088}
          height={1440}
          className="h-[340px] w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/25 to-transparent" />

        <div className="absolute left-0 right-0 top-0 flex items-center justify-between p-5">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-full bg-wind font-display text-lg leading-none text-foam">
              {school.name.charAt(0).toUpperCase()}
            </span>
            <span className="font-display text-xl tracking-wide text-foam">
              {(school.name.split(" ")[0] ?? "VENTO").toUpperCase()}
            </span>
          </div>
          <span className="text-xs font-medium text-foam/80">{school.city}</span>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-wind">
            Próxima aula
          </p>
          <h1 className="max-w-[16ch] text-balance font-display text-5xl leading-none text-foam">
            Aula de <span className="text-wind">Kite</span> hoje
          </h1>
          <p className="mt-2 max-w-[30ch] text-pretty text-sm text-foam/85">
            {spot?.name} · {availability[0]?.times[0] ?? "08:00"} · 3 vagas restantes
          </p>
          <Link
            to="/agenda"
            className="mt-4 inline-flex items-center gap-2 rounded-full bg-wind px-5 py-3 text-sm font-semibold text-foam ring-1 ring-wind/40"
          >
            Reservar agora
            <span className="grid size-4 shrink-0 place-items-center">→</span>
          </Link>
        </div>
      </section>

      {/* PACOTES */}
      <section className="py-6">
        <div className="px-5">
          <div className="mb-4 flex items-end justify-between">
            <h2 className="text-balance font-display text-3xl leading-none">Pacotes de aula</h2>
            <span className="text-xs font-medium text-sea">a partir de {formatPrice(cheapest)}</span>
          </div>

          <div className="space-y-3">
            {school.lessons.map((lesson) => {
              const featured = lesson.featured;
              return (
                <button
                  key={lesson.id}
                  type="button"
                  onClick={() => setLessonId(lesson.id)}
                  className={`block w-full rounded-[28px] p-5 text-left ring-1 ring-border transition-transform active:scale-[0.99] ${
                    featured ? "bg-ink text-foam" : "bg-foam"
                  } ${lessonId === lesson.id ? "ring-2 ring-wind" : ""}`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-semibold uppercase tracking-[0.15em] ${
                        featured ? "text-wind" : "text-sea"
                      }`}
                    >
                      {featured ? "Mais pedido" : lesson.level}
                    </span>
                    <span className="font-display text-3xl leading-none">
                      {formatPrice(lesson.price)}
                    </span>
                  </div>
                  <h3 className="mt-3 font-display text-2xl leading-none">{lesson.name}</h3>
                  <p className={`mt-1 text-sm ${featured ? "text-foam/70" : "text-ink/60"}`}>
                    {lesson.detail}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    <span
                      className={`rounded-full px-3 py-1 text-[11px] font-medium ${
                        featured ? "bg-foam/10" : "bg-sand"
                      }`}
                    >
                      {lesson.level}
                    </span>
                    <span
                      className={`rounded-full px-3 py-1 text-[11px] font-medium ${
                        featured ? "bg-foam/10" : "bg-sand"
                      }`}
                    >
                      {lesson.languages.join(" · ")}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* SPOTS */}
      <section className="py-6">
        <div className="mb-4 flex items-end justify-between px-5">
          <h2 className="text-balance font-display text-3xl leading-none">Spots</h2>
          <Link to="/spots" className="text-xs font-medium text-sea">
            ver todos
          </Link>
        </div>
        <div className="no-scrollbar snap-strip flex gap-3 overflow-x-auto px-5 pb-2">
          {school.spots.map((s) => (
            <div key={s.id} className="w-[240px] shrink-0 snap-start">
              <img
                src={spotImageFor(s.id)}
                alt={s.name}
                loading="lazy"
                width={1024}
                height={1024}
                className="aspect-[4/5] w-full rounded-[24px] object-cover"
              />
              <div className="mt-3">
                <h3 className="font-display text-xl leading-none">{s.name}</h3>
                <div className="mt-2 flex items-center gap-3 text-xs font-medium">
                  <span className="text-wind">Vento {s.wind}</span>
                  <span className="text-ink/50">{s.sea}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* DISPONIBILIDADE */}
      <section className="py-6">
        <div className="mb-4 px-5">
          <h2 className="text-balance font-display text-3xl leading-none">Disponibilidade</h2>
        </div>
        <div className="no-scrollbar snap-strip flex gap-2 overflow-x-auto px-5 pb-2">
          {availability.map((slot, index) => {
            const active = index === dayIndex;
            return (
              <div
                key={slot.date}
                className={`w-[150px] shrink-0 snap-start rounded-[20px] p-4 ${
                  active ? "bg-wind text-foam" : "bg-foam ring-1 ring-border"
                }`}
              >
                <p className={`text-xs font-medium ${active ? "text-foam/70" : "text-ink/50"}`}>
                  {slot.day}
                </p>
                <p className="mt-1 font-display text-2xl leading-none">{slot.date}</p>
                <div className="mt-3 space-y-1.5">
                  {slot.times.map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => {
                        setDayIndex(index);
                        setTime(t);
                      }}
                      className={`block w-full rounded-full px-2 py-1 text-[11px] font-medium ${
                        active
                          ? t === time
                            ? "bg-foam text-wind"
                            : "bg-foam/20"
                          : "bg-sand text-ink"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* PRÉ-RESERVA */}
      <section className="px-5 pb-8">
        <div className="rounded-[28px] bg-foam p-5 ring-1 ring-border">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-2xl leading-none">Pré-reserva</h2>
            <span className="text-xs font-medium text-sea">
              {day.day} {day.date} · {time}
            </span>
          </div>

          <ChipGroup
            label="Nível"
            options={LEVELS}
            value={profile.level}
            onChange={(level) => updateProfile({ ...profile, level })}
          />
          <ChipGroup
            label="Peso"
            options={WEIGHTS}
            value={profile.weight}
            onChange={(weight) => updateProfile({ ...profile, weight })}
          />
          <ChipGroup
            label="Altura"
            options={HEIGHTS}
            value={profile.height}
            onChange={(height) => updateProfile({ ...profile, height })}
          />
          <ChipGroup
            label="Tamanho de roupa"
            options={CLOTHING}
            value={profile.clothing}
            onChange={(clothing) => updateProfile({ ...profile, clothing })}
          />
          <ChipGroup
            label="Tamanho de calçado"
            options={SHOES}
            value={profile.shoe}
            onChange={(shoe) => updateProfile({ ...profile, shoe })}
          />
          <ChipGroup
            label="Idioma"
            options={LANGUAGES}
            value={profile.language}
            onChange={(language) => updateProfile({ ...profile, language })}
          />

          <button
            type="button"
            onClick={submit}
            className="w-full rounded-full bg-ink py-3.5 text-sm font-semibold text-foam ring-1 ring-ink/40 transition-transform active:scale-[0.99]"
          >
            Continuar
          </button>
        </div>
      </section>
    </div>
  );
}
