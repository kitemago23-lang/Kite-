import { createFileRoute, Link } from "@tanstack/react-router";
import { spotImageFor } from "@/components/spot-images";
import { useSchool } from "@/lib/school-store";

export const Route = createFileRoute("/spots")({
  head: () => ({
    meta: [
      { title: "Spots de kitesurf no Ceará · VENTO" },
      {
        name: "description",
        content:
          "Locais onde as aulas acontecem: Ilha do Guajiru, Icaraí de Amontada e Fortaleza, com vento e condições do mar.",
      },
      { property: "og:title", content: "Spots de kitesurf no Ceará · VENTO" },
      {
        property: "og:description",
        content: "Conheça as praias onde as aulas de kitesurf acontecem no Ceará.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Spots,
});

function Spots() {
  const { value: school } = useSchool();

  return (
    <div className="px-5 pt-8">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-wind">Locais das aulas</p>
      <h1 className="mt-2 text-balance font-display text-4xl leading-none">Spots</h1>
      <p className="mt-2 max-w-[32ch] text-pretty text-sm text-ink/60">
        Praias onde {school.name} dá aula, com vento médio e condição do mar.
      </p>

      <div className="mt-6 space-y-4">
        {school.spots.map((spot) => (
          <div key={spot.id} className="overflow-hidden rounded-[28px] bg-foam ring-1 ring-border">
            <img
              src={spotImageFor(spot.id)}
              alt={spot.name}
              loading="lazy"
              width={1024}
              height={1024}
              className="h-44 w-full object-cover"
            />
            <div className="p-5">
              <h2 className="font-display text-2xl leading-none">{spot.name}</h2>
              <div className="mt-3 flex items-center gap-3 text-xs font-medium">
                <span className="rounded-full bg-sand px-3 py-1 text-wind">Vento {spot.wind}</span>
                <span className="rounded-full bg-sand px-3 py-1 text-ink/60">{spot.sea}</span>
              </div>
              <Link
                to="/agenda"
                className="mt-4 inline-flex rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-foam"
              >
                Ver disponibilidade
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
