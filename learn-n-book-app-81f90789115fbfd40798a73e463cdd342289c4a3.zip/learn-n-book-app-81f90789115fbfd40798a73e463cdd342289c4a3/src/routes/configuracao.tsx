import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { formatPrice, useSchool } from "@/lib/school-store";

export const Route = createFileRoute("/configuracao")({
  head: () => ({
    meta: [
      { title: "Configuração da escola · VENTO" },
      { name: "description", content: "Configure o nome da escola de kitesurf, locais atendidos e preços das aulas." },
      { property: "og:title", content: "Configuração da escola · VENTO" },
      { property: "og:description", content: "Edite nome, locais de aula e preços exibidos no aplicativo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Configuracao,
});

function Configuracao() {
  const { value: school, update } = useSchool();
  const [draft, setDraft] = useState(school);
  const [saved, setSaved] = useState(false);

  const save = () => {
    update(draft);
    setSaved(true);
  };

  return (
    <div className="px-5 pt-8">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-wind">Área da escola</p>
      <h1 className="mt-2 font-display text-4xl leading-none">Configuração</h1>
      <p className="mt-2 text-sm text-ink/60">Personalize as informações que os alunos verão no aplicativo.</p>

      <div className="mt-6 space-y-5 rounded-[28px] bg-foam p-5 ring-1 ring-border">
        <div>
          <label htmlFor="school-name" className="mb-2 block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">Nome da escola</label>
          <input id="school-name" maxLength={80} value={draft.name} onChange={(event) => { setSaved(false); setDraft({ ...draft, name: event.target.value }); }} className="w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-wind" />
        </div>
        <div>
          <label htmlFor="school-city" className="mb-2 block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">Base principal</label>
          <input id="school-city" maxLength={80} value={draft.city} onChange={(event) => { setSaved(false); setDraft({ ...draft, city: event.target.value }); }} className="w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-wind" />
        </div>
      </div>

      <section className="mt-7">
        <h2 className="font-display text-2xl">Locais de aula</h2>
        <div className="mt-3 space-y-3">
          {draft.spots.map((spot, index) => (
            <div key={spot.id} className="rounded-[24px] bg-foam p-4 ring-1 ring-border">
              <label htmlFor={`spot-${spot.id}`} className="mb-2 block text-xs font-semibold text-ink/50">Local {index + 1}</label>
              <input id={`spot-${spot.id}`} maxLength={100} value={spot.name} onChange={(event) => { const spots = draft.spots.map((item) => item.id === spot.id ? { ...item, name: event.target.value } : item); setSaved(false); setDraft({ ...draft, spots }); }} className="w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-wind" />
            </div>
          ))}
        </div>
      </section>

      <section className="mt-7">
        <h2 className="font-display text-2xl">Preços</h2>
        <div className="mt-3 space-y-3">
          {draft.lessons.map((lesson) => (
            <div key={lesson.id} className="rounded-[24px] bg-foam p-4 ring-1 ring-border">
              <div className="mb-3 flex items-center justify-between"><strong className="text-sm">{lesson.name}</strong><span className="font-display text-xl text-wind">{formatPrice(lesson.price)}</span></div>
              <label htmlFor={`price-${lesson.id}`} className="sr-only">Preço de {lesson.name}</label>
              <input id={`price-${lesson.id}`} type="number" min={0} max={100000} step={10} value={lesson.price} onChange={(event) => { const price = Math.min(100000, Math.max(0, Number(event.target.value))); const lessons = draft.lessons.map((item) => item.id === lesson.id ? { ...item, price } : item); setSaved(false); setDraft({ ...draft, lessons }); }} className="w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-wind" />
            </div>
          ))}
        </div>
      </section>

      <button type="button" onClick={save} className="my-7 w-full rounded-full bg-ink py-3.5 text-sm font-semibold text-foam">{saved ? "Configurações salvas" : "Salvar configurações"}</button>
    </div>
  );
}