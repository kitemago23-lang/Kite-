import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { availability, formatPrice, useBookings, useSchool } from "@/lib/school-store";

export const Route = createFileRoute("/agenda")({
  head: () => ({
    meta: [
      { title: "Agenda e pré-reservas · VENTO" },
      { name: "description", content: "Consulte horários disponíveis e acompanhe suas pré-reservas de kitesurf." },
      { property: "og:title", content: "Agenda e pré-reservas · VENTO" },
      { property: "og:description", content: "Horários disponíveis e pré-reservas de aulas de kitesurf no Ceará." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Agenda,
});

function Agenda() {
  const { value: school } = useSchool();
  const { bookings, add, remove } = useBookings();
  const [dayIndex, setDayIndex] = useState(0);
  const [time, setTime] = useState(availability[0]?.times[0] ?? "08:00");
  const [lessonId, setLessonId] = useState(school.lessons[0]?.id ?? "");
  const [spotId, setSpotId] = useState(school.spots[0]?.id ?? "");
  const day = availability[dayIndex] ?? availability[0] ?? { day: "Seg", date: "12", times: ["08:00"] };

  const confirm = () => add({ lessonId, spotId, day: `${day.day} ${day.date}`, time });

  return (
    <div className="px-5 pt-8">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-wind">Escolha seu horário</p>
      <h1 className="mt-2 font-display text-4xl leading-none">Agenda</h1>

      <div className="no-scrollbar snap-strip -mx-5 mt-6 flex gap-2 overflow-x-auto px-5 pb-2">
        {availability.map((slot, index) => (
          <button
            key={slot.date}
            type="button"
            onClick={() => {
              setDayIndex(index);
              setTime(slot.times[0] ?? "08:00");
            }}
            className={`w-[104px] shrink-0 snap-start rounded-[20px] p-4 text-left ${index === dayIndex ? "bg-wind text-foam" : "bg-foam ring-1 ring-border"}`}
          >
            <span className="text-xs font-medium opacity-70">{slot.day}</span>
            <strong className="mt-1 block font-display text-2xl font-normal">{slot.date}</strong>
            <span className="mt-2 block text-[11px] font-medium">{slot.times.length} horários</span>
          </button>
        ))}
      </div>

      <div className="mt-5 rounded-[28px] bg-foam p-5 ring-1 ring-border">
        <label className="block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50" htmlFor="lesson">Aula</label>
        <select id="lesson" value={lessonId} onChange={(event) => setLessonId(event.target.value)} className="mt-2 w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none ring-wind focus:ring-2">
          {school.lessons.map((lesson) => <option key={lesson.id} value={lesson.id}>{lesson.name} · {formatPrice(lesson.price)}</option>)}
        </select>

        <label className="mt-5 block text-xs font-semibold uppercase tracking-[0.15em] text-ink/50" htmlFor="spot">Local</label>
        <select id="spot" value={spotId} onChange={(event) => setSpotId(event.target.value)} className="mt-2 w-full rounded-xl bg-sand px-4 py-3 text-sm outline-none ring-wind focus:ring-2">
          {school.spots.map((spot) => <option key={spot.id} value={spot.id}>{spot.name}</option>)}
        </select>

        <p className="mt-5 text-xs font-semibold uppercase tracking-[0.15em] text-ink/50">Horário</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {day.times.map((entry) => (
            <button key={entry} type="button" onClick={() => setTime(entry)} className={entry === time ? "rounded-full bg-wind px-4 py-2 text-sm font-medium text-foam" : "rounded-full bg-sand px-4 py-2 text-sm font-medium"}>{entry}</button>
          ))}
        </div>

        <button type="button" onClick={confirm} className="mt-6 w-full rounded-full bg-ink py-3.5 text-sm font-semibold text-foam">Fazer pré-reserva</button>
      </div>

      <section className="py-7">
        <h2 className="font-display text-2xl leading-none">Minhas pré-reservas</h2>
        {bookings.length === 0 ? (
          <div className="mt-4 rounded-[24px] bg-sand-2 p-5 text-sm text-ink/60">
            Nenhuma pré-reserva ainda. Complete também seu <Link to="/perfil" className="font-semibold text-sea">perfil de aluno</Link>.
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            {bookings.map((booking) => {
              const lesson = school.lessons.find((item) => item.id === booking.lessonId);
              const spot = school.spots.find((item) => item.id === booking.spotId);
              return (
                <div key={booking.id} className="rounded-[24px] bg-foam p-5 ring-1 ring-border">
                  <div className="flex items-start justify-between gap-4">
                    <div><h3 className="font-display text-xl">{lesson?.name ?? "Aula"}</h3><p className="mt-1 text-xs text-ink/60">{spot?.name} · {booking.day} · {booking.time}</p></div>
                    <button type="button" onClick={() => remove(booking.id)} className="text-xs font-semibold text-wind">Cancelar</button>
                  </div>
                  <span className="mt-3 inline-block rounded-full bg-sand px-3 py-1 text-[11px] font-medium text-sea">Aguardando confirmação</span>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}